// Bausteine für Eingabefelder mit Prüfmeldungen am Feld.

import { createContext, useContext, useId, type ReactNode } from "react";

import type { Endpunkt, Problem, Quelle, Stufe } from "../api";
import { system } from "../system";
import { endpunktVom, problemeAn, quelleVom } from "./modell";

/** Alle aktuellen Prüfmeldungen; jedes Feld zeigt die zu seinem Ort. */
export const ProblemeKontext = createContext<Problem[]>([]);

/** Beschriftetes Feld; `kind` erhält die Kennung für `id`/`htmlFor`. */
export function Feld({ label, ort, kind }: { label: string; ort: string; kind: (id: string) => ReactNode }) {
  const id = useId();
  const probleme = problemeAn(useContext(ProblemeKontext), ort);
  return (
    <div className="feld">
      <label htmlFor={id}>{label}</label>
      {kind(id)}
      {probleme.map((p, i) => (
        <span key={i} className={`feld-meldung ${p.schwere}`}>
          {p.meldung}
        </span>
      ))}
    </div>
  );
}

export function TextFeld(props: {
  label: string;
  ort: string;
  wert: string;
  onChange: (w: string) => void;
  nurLesen?: boolean;
  platzhalter?: string;
}) {
  return (
    <Feld
      label={props.label}
      ort={props.ort}
      kind={(id) => (
        <input
          id={id}
          value={props.wert}
          readOnly={props.nurLesen}
          placeholder={props.platzhalter}
          onChange={(e) => props.onChange(e.target.value)}
        />
      )}
    />
  );
}

export function AuswahlFeld<T extends string>(props: {
  label: string;
  ort: string;
  wert: T;
  optionen: [T, string][];
  onChange: (w: T) => void;
}) {
  return (
    <Feld
      label={props.label}
      ort={props.ort}
      kind={(id) => (
        <select id={id} value={props.wert} onChange={(e) => props.onChange(e.target.value as T)}>
          {props.optionen.map(([w, text]) => (
            <option key={w} value={w}>
              {text}
            </option>
          ))}
        </select>
      )}
    />
  );
}

/** Lokaler Pfad mit Auswahldialog. */
export function PfadFeld(props: { label: string; ort: string; wert: string; onChange: (w: string) => void }) {
  async function waehlen() {
    const pfad = await system.ordnerWaehlen(props.wert);
    if (pfad) props.onChange(pfad);
  }
  return (
    <Feld
      label={props.label}
      ort={props.ort}
      kind={(id) => (
        <div className="pfad">
          <input id={id} value={props.wert} placeholder="/Users/…" onChange={(e) => props.onChange(e.target.value)} />
          <button type="button" onClick={waehlen}>
            Wählen …
          </button>
        </div>
      )}
    />
  );
}

/** Felder eines lokalen oder FTPS-Endpunkts. `ort` ist z. B. `stufen[0].ziel`. */
export function EndpunktFelder({ wert, ort, onChange }: { wert: Endpunkt; ort: string; onChange: (e: Endpunkt) => void }) {
  if (wert.typ === "lokal") {
    return <PfadFeld label="Ordner" ort={`${ort}.pfad`} wert={wert.pfad} onChange={(pfad) => onChange({ ...wert, pfad })} />;
  }
  const setze = (teil: Partial<Endpunkt & { typ: "ftps" }>) => onChange({ ...wert, ...teil });
  return (
    <div className="ftps">
      <TextFeld label="Server" ort={`${ort}.host`} wert={wert.host} platzhalter="ftp.example.de" onChange={(host) => setze({ host })} />
      <TextFeld
        label="Port"
        ort={`${ort}.port`}
        wert={String(wert.port)}
        onChange={(p) => setze({ port: Number.parseInt(p, 10) || 0 })}
      />
      <TextFeld label="Serverpfad" ort={`${ort}.pfad`} wert={wert.pfad} onChange={(pfad) => setze({ pfad })} />
      <TextFeld label="Benutzer" ort={`${ort}.benutzer`} wert={wert.benutzer} onChange={(benutzer) => setze({ benutzer })} />
      <TextFeld
        label="Schlüsselbund-Eintrag"
        ort={`${ort}.konto_ref`}
        wert={wert.konto_ref}
        onChange={(konto_ref) => setze({ konto_ref })}
      />
      <p className="hinweis">
        Verbindung immer mit explizitem TLS. Das Passwort wird im Schlüsselbund hinterlegt, sobald die
        FTPS-Übertragung umgesetzt ist – nie in der Konfiguration.
      </p>
    </div>
  );
}

/** Quelle einer Stufe: lokal, FTPS oder das Ziel einer Vorstufe. */
export function QuelleFelder(props: {
  wert: Quelle;
  ort: string;
  vorstufen: Stufe[];
  konto: string;
  onChange: (q: Quelle) => void;
}) {
  const { wert, ort, vorstufen } = props;
  const typen: [Quelle["typ"], string][] = [
    ["lokal", "Lokaler Ordner"],
    ["ftps", "FTPS-Server"],
  ];
  // Auch ohne Vorstufe anbieten, wenn bereits gesetzt (z. B. nach Entfernen der Vorstufe) –
  // die Prüfung meldet den Fehler dann am Feld.
  if (vorstufen.length > 0 || wert.typ === "stufe") typen.push(["stufe", "Ziel einer Vorstufe"]);
  const vorletzte = vorstufen[vorstufen.length - 1]?.id;
  return (
    <>
      <AuswahlFeld
        label="Art"
        ort={`${ort}.typ`}
        wert={wert.typ}
        optionen={typen}
        onChange={(typ) => props.onChange(quelleVom(typ, props.konto, vorletzte))}
      />
      {wert.typ === "stufe" ? (
        <AuswahlFeld
          label="Vorstufe"
          ort={`${ort}.stufe`}
          wert={wert.stufe}
          optionen={vorstufen.map((s) => [s.id, s.name || s.id])}
          onChange={(stufe) => props.onChange({ typ: "stufe", stufe })}
        />
      ) : (
        <EndpunktFelder wert={wert} ort={ort} onChange={props.onChange} />
      )}
    </>
  );
}

/** Art eines Ziels wählen und dessen Felder zeigen. */
export function ZielFelder(props: { wert: Endpunkt; ort: string; konto: string; onChange: (e: Endpunkt) => void }) {
  return (
    <>
      <AuswahlFeld
        label="Art"
        ort={`${props.ort}.typ`}
        wert={props.wert.typ}
        optionen={[
          ["lokal", "Lokaler Ordner"],
          ["ftps", "FTPS-Server"],
        ]}
        onChange={(typ) => props.onChange(endpunktVom(typ, props.konto))}
      />
      <EndpunktFelder wert={props.wert} ort={props.ort} onChange={props.onChange} />
    </>
  );
}
